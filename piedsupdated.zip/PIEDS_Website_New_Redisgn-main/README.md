# PIEDS_Website_New_Redisgn
This is new website design for the PIEDS
Suggestions :
1.) Please keep files in rights folders, like all logos and images in images folder, css files in bootstrap/css etc.
2.) Please make new css and js files for every new page made, this lowers the confusion and editing specific component easy without disturbing other elements. (I know it will take a lot of time, but it will help us in future, I hope you all understand :) )
3.) Please name all files correctly and try to use camelCase for consistency.
4.) We all got this, we all will make this website one of the best.

OP bois
